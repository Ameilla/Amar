//
//  SampleViewController.swift
//  MOCA
//
//  Created by SAIL L1 on 05/10/23.
//

import UIKit

class SampleViewController: UIViewController{
   
var nameList = ["Amar","Thansih","Dhanesh"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        
        // Do any additional setup after loading the view.
    }
    
    

}
